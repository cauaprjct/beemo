@echo off
chcp 65001 >nul
title Beemo Office Agent - Configuração
color 0E

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║         🎮 BEEMO OFFICE AGENT - CONFIGURAÇÃO 🎮           ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.
echo.

if not exist .env (
    echo ❌ Arquivo .env não encontrado!
    echo Execute primeiro o INSTALAR.bat
    echo.
    pause
    exit /b 1
)

echo Abrindo arquivo de configuração...
echo.
notepad .env

echo.
echo ✅ Configuração concluída!
echo.
echo Execute EXECUTAR.bat para iniciar o Beemo
echo.
pause
