@echo off
chcp 65001 >nul
title Beemo Office Agent
color 0B

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║              🎮 BEEMO OFFICE AGENT 🎮                      ║
echo ║                                                            ║
echo ║         Assistente Office com Inteligência Artificial      ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.
echo.

REM Verificar se .env existe
if not exist .env (
    echo ❌ ERRO: Arquivo .env não encontrado!
    echo.
    echo Execute primeiro o arquivo INSTALAR.bat
    echo.
    pause
    exit /b 1
)

REM Verificar se API Key está configurada
findstr /C:"your_api_key_here" .env >nul
if not errorlevel 1 (
    echo ⚠️  ATENÇÃO: API Key não configurada!
    echo.
    echo Você precisa configurar sua API Key do Google Gemini no arquivo .env
    echo.
    echo 1. Obtenha sua chave gratuita em: https://aistudio.google.com/apikey
    echo 2. Abra o arquivo .env
    echo 3. Substitua "your_api_key_here" pela sua chave
    echo.
    echo Deseja abrir o arquivo .env agora? (S/N)
    set /p OPEN_ENV=
    if /i "%OPEN_ENV%"=="S" (
        notepad .env
        echo.
        echo Após configurar, execute este arquivo novamente.
        echo.
        pause
        exit /b 0
    )
    echo.
    pause
    exit /b 1
)

echo 🚀 Iniciando Beemo Office Agent...
echo.
echo ⏳ Aguarde, o navegador abrirá automaticamente...
echo.
echo 💡 Para encerrar, feche esta janela ou pressione Ctrl+C
echo.
echo ════════════════════════════════════════════════════════════
echo.

REM Executar Streamlit
streamlit run app.py --server.headless true

REM Se o Streamlit falhar
if errorlevel 1 (
    echo.
    echo ❌ ERRO ao iniciar o Beemo!
    echo.
    echo Possíveis soluções:
    echo 1. Execute INSTALAR.bat novamente
    echo 2. Verifique se o Python está instalado corretamente
    echo 3. Verifique se todas as dependências foram instaladas
    echo.
    pause
)
