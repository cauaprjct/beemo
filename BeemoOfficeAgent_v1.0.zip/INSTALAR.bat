@echo off
chcp 65001 >nul
title Beemo Office Agent - Instalador
color 0A

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║           🎮 BEEMO OFFICE AGENT - INSTALADOR 🎮           ║
echo ║                                                            ║
echo ║              Assistente Office com IA                      ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.
echo.

REM Verificar se Python está instalado
echo [1/5] Verificando Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo ❌ ERRO: Python não encontrado!
    echo.
    echo Por favor, instale o Python 3.8 ou superior:
    echo https://www.python.org/downloads/
    echo.
    echo ⚠️  IMPORTANTE: Marque a opção "Add Python to PATH" durante a instalação
    echo.
    pause
    exit /b 1
)
echo ✅ Python encontrado!
python --version
echo.

REM Verificar se pip está instalado
echo [2/5] Verificando pip...
pip --version >nul 2>&1
if errorlevel 1 (
    echo ❌ ERRO: pip não encontrado!
    echo Instalando pip...
    python -m ensurepip --upgrade
)
echo ✅ pip encontrado!
echo.

REM Instalar dependências
echo [3/5] Instalando dependências (pode demorar alguns minutos)...
echo.
pip install -r requirements.txt --quiet --disable-pip-version-check
if errorlevel 1 (
    echo.
    echo ❌ ERRO ao instalar dependências!
    echo Tente executar manualmente: pip install -r requirements.txt
    echo.
    pause
    exit /b 1
)
echo ✅ Dependências instaladas com sucesso!
echo.

REM Configurar .env se não existir
echo [4/5] Configurando ambiente...
if not exist .env (
    echo Criando arquivo de configuração...
    copy .env.example .env >nul
    echo ✅ Arquivo .env criado!
    echo.
    echo ⚠️  ATENÇÃO: Você precisa configurar sua API Key do Google Gemini
    echo.
    echo 1. Abra o arquivo .env com o Bloco de Notas
    echo 2. Obtenha sua API Key gratuita em: https://aistudio.google.com/apikey
    echo 3. Substitua "your_api_key_here" pela sua chave
    echo 4. Configure o caminho da pasta de arquivos (ROOT_PATH)
    echo.
    echo Deseja abrir o arquivo .env agora? (S/N)
    set /p OPEN_ENV=
    if /i "%OPEN_ENV%"=="S" (
        notepad .env
    )
) else (
    echo ✅ Arquivo .env já existe!
)
echo.

REM Criar pasta de arquivos se não existir
echo [5/5] Criando estrutura de pastas...
if not exist logs mkdir logs
if not exist .versions mkdir .versions
echo ✅ Pastas criadas!
echo.

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║              ✅ INSTALAÇÃO CONCLUÍDA! ✅                   ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.
echo.
echo 📋 PRÓXIMOS PASSOS:
echo.
echo 1. Configure sua API Key no arquivo .env (se ainda não fez)
echo    • Obtenha em: https://aistudio.google.com/apikey
echo.
echo 2. Execute o arquivo EXECUTAR.bat para iniciar o Beemo
echo.
echo 3. O navegador abrirá automaticamente com a interface
echo.
echo.
echo 💡 DICA: Crie um atalho do EXECUTAR.bat na área de trabalho!
echo.
echo.
pause
